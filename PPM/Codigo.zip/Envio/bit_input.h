//
// Created by Victor on 22/04/2022.
//

#ifndef PPM_BIT_INPUT_H
#define PPM_BIT_INPUT_H

#include <stdio.h>

void start_inputing_bits();
int input_bit(FILE *file);

#endif //PPM_BIT_INPUT_H
