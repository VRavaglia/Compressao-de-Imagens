Execute,

make all

para compilar tanto condificador quanto decodificador. Execute cada um para receber as instruções de uso.